#ifndef BUSCAR_H_
    #define BUSCAR_H_

    #include "registro.h"

    #include <stdio.h>

    void BuscarComFiltro(FILE *arquivo, REGISTRO *reg);
    void Buscar(FILE *arquivo);
#endif