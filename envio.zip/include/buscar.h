#ifndef BUSCAR_H_
    #define BUSCAR_H_

    #include <stdio.h>

    void BuscarRegistros(FILE *file);
    void BuscarRegistrosCondicional(FILE *file);

#endif