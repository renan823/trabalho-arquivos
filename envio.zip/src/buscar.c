#include "buscar.h"

#include <stdlib.h>
#include <stdio.h>

void BuscarRegistros(FILE *file) {

}


void BuscarRegistrosCondicional(FILE *file) {

}