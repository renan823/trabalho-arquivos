#include "erros.h"
#include "cabecalho.h"
#include "registro.h"
#include "utils.h"
#include "buscar.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* 
Função que le registros em um CSV e armazena em um arquivo binário
*/
void FUNCIONALIDADE1(void){
    // Ler nome dos arquivos de entrada e saída.
    char *nomeArquivoEntrada = LerString();
    char *nomeArquivoSaida = LerString();
    // Abrir arquivos de entrada e saída
    FILE *arquivoEntrada = fopen(nomeArquivoEntrada, "r");

    // Verificar se o arquivo de entrada existe
    if(arquivoEntrada == NULL){
        // Dispara mensagem de erro
        DispararErro(ErroProcessamentoArquivo());
    } else {
        FILE *arquivoSaida = fopen(nomeArquivoSaida, "wb");
        
        // Verifica se o arquivo foi criado
        if(arquivoSaida == NULL){
            // Dispara erro fatal
            DispararErro(ErroCriarArquivo());
        }

        // Ler CSV do arquivo de entrada e escreve em binário no de saída.
        LerCsvParaBinario(arquivoEntrada, arquivoSaida);

        // Fechar arquivos de entrada e saída
        fclose(arquivoEntrada);
        fclose(arquivoSaida);

        // Executar função fornecida para  
        // mostrar a saída do arquivo ataques.bin
        binarioNaTela(nomeArquivoSaida);
    }
    // Liberar memória do nome dos arquivos
    free(nomeArquivoEntrada);
    nomeArquivoEntrada = NULL;
    free(nomeArquivoSaida);
    nomeArquivoSaida = NULL;

    return;
}

/*
Exibe os registros no arquivo de dados informado
*/
void FUNCIONALIDADE2(void) {
    // Ler nome dos arquivos de entrada e saída.
    char *nomeArquivoEntrada = LerString();

    // Abrir arquivos de entrada
    FILE *arquivoEntrada = fopen(nomeArquivoEntrada, "rb");

    // Verificar se arquivo de entrada existe
    if(arquivoEntrada == NULL){
        // Dispara mensagem de erro
        DispararErro(ErroProcessamentoArquivo());
    } else {
        // Imprimir todos os registros.
        Buscar(arquivoEntrada);
        // Fechar arquivo
        fclose(arquivoEntrada);
        arquivoEntrada = NULL;
    }
    // Liberar memória 
    free(nomeArquivoEntrada);
    nomeArquivoEntrada = NULL;

    return;
}

/*
Busca registros de acordo com um filtro
*/
void FUNCIONALIDADE3(void){
    // Ler nome dos arquivos de entrada e saída.
    char *nomeArquivoEntrada = LerString();

    // Abrir arquivos de entrada
    FILE *arquivoEntrada = fopen(nomeArquivoEntrada, "rb");

    // Quantidades de buscas a serem realizadas
    int quantBuscas;
    scanf("%d", &quantBuscas);

    // Verificar se arquivo de entrada existe
    if(arquivoEntrada == NULL){
        // Dispara mensagem de erro
        DispararErro(ErroProcessamentoArquivo());
    } else {
        while(quantBuscas--){
            // Quantidade de campos em cada busca(filtros).
            int quantCampos;
            scanf("%d", &quantCampos);

            // Registro a ser usado como filtro
            REGISTRO *reg = CriarRegistroVazio();

            // Ler campos inseridos pelo usuário
            for(int i = 0; i < quantCampos; i++){
                char *campo = LerString();
                // Switch case do campo
                if(!strcmp(campo, "idAttack")){
                    scanf(" %d", &(reg->idAttack));
                } else if(!strcmp(campo, "year")) {
                    scanf(" %d", &(reg->year));
                } else if(!strcmp(campo, "financialLoss")) {
                    scanf(" %f", &(reg->financialLoss));
                } else if(!strcmp(campo, "country")) {
                    reg->country = LerStringComAspas();
                } else if(!strcmp(campo, "attackType")) {
                    reg->attackType = LerStringComAspas();
                } else if(!strcmp(campo, "targetIndustry")) {
                    reg->targetIndustry = LerStringComAspas();
                } else if(!strcmp(campo, "defenseMechanism")) {
                    reg->defenseMechanism = LerStringComAspas();
                } else {
                    // TODO: erro select invalido
                }

                free(campo);
                campo = NULL;
            }

            BuscarComFiltro(arquivoEntrada, reg);
            // Apagar registro filtro
            ApagarRegistro(&reg);
        }
        // Fechar arquivo
        fclose(arquivoEntrada);
        arquivoEntrada = NULL;
    }   

    // Liberar memória 
    free(nomeArquivoEntrada);
    nomeArquivoEntrada = NULL;

    return;
}

int main(void) {
    // Ler funcionalidade selecionada e nome arquivo de entrada
    int funcionalidade;
    scanf("%d", &funcionalidade);

    switch (funcionalidade){
        case 1:
            FUNCIONALIDADE1();
            break;
        case 2:
            FUNCIONALIDADE2();
            break;
        case 3:
            FUNCIONALIDADE3();
            break;

        default:
            break;
    }   
    return 0;
}